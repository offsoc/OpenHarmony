# OpenHarmony中的bpftool预编译工具 说明

# 功能

    bpftool是用来检查和处理eBPF程序和maps的工具，在本项目里被用于hiebpf插件中。

 
# 构建指导


```

# 获取代码

repo init -u https://gitee.com/openharmony/manifest.git -b bpftool_toolchain-dev

repo sync -c

repo forall -c 'git lfs pull'

# 编译bpftool预编译工具

sudo apt install zlib1g-dev  libelf-dev

cd OpenHarmony/kernel/linux/linux-5.10/tools/bpf/bpftool

make

```

## 更新预编译工具

 

在OpenHarmony项目中运行脚本：

 

```

$ ./build/prebuilts_download.sh

```

## 开源许可

 

SPDX-License-Identifier: GPL-2.0-only OR BSD-2-Clause